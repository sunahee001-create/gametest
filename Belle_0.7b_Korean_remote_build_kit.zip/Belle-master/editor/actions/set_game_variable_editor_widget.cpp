/* Copyright (C) 2012-2014 Carlos Pais
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "set_game_variable_editor_widget.h"
#include "variablevalidator.h"

SetGameVariableEditorWidget::SetGameVariableEditorWidget(ActionEditorWidget *parent) :
    ActionEditorWidget(parent)
{
    mVariableEdit = new QLineEdit(this);
    mVariableEdit->setValidator(new VariableValidator(this));

    mOperatorChooser = new QComboBox(this);
    mOperatorChooser->addItem(tr("대입"));
    mOperatorChooser->addItem(tr("더하기"));
    mOperatorChooser->addItem(tr("빼기"));
    mOperatorChooser->addItem(tr("곱하기"));
    mOperatorChooser->addItem(tr("나누기"));
    mOperatorChooser->addItem(tr("뒤에 추가"));

    mValueEdit = new QLineEdit(this);

    connect(mVariableEdit, SIGNAL(textEdited(const QString&)), this, SLOT(onVariableEdited(const QString&)));
    connect(mOperatorChooser, SIGNAL(currentIndexChanged(int)), this, SLOT(onOperatorChanged(int)));
    connect(mValueEdit, SIGNAL(textEdited(const QString&)), this, SLOT(onValueEdited(const QString&)));

    beginGroup(tr("게임 변수"));
    appendRow(tr("변수"), mVariableEdit);
    appendRow(tr("연산자"), mOperatorChooser);
    appendRow(tr("값"), mValueEdit);
    endGroup();

    resizeColumnToContents(0);
}

void  SetGameVariableEditorWidget::updateData(GameObject* action)
{
    ActionEditorWidget::updateData(action);
    SetGameVariable* setGameVariable = qobject_cast<SetGameVariable*>(action);
    if (! setGameVariable)
        return;

    mVariableEdit->setText(setGameVariable->variable());
    mOperatorChooser->setCurrentIndex(setGameVariable->operatorIndex());
    mValueEdit->setText(setGameVariable->value());
}

void SetGameVariableEditorWidget::onVariableEdited(const QString & text)
{
    SetGameVariable* setGameVariable = qobject_cast<SetGameVariable*>(mGameObject);
    if (setGameVariable)
        setGameVariable->setVariable(text);
}

void SetGameVariableEditorWidget::onOperatorChanged(int index)
{
    SetGameVariable* setGameVariable = qobject_cast<SetGameVariable*>(mGameObject);
    if (setGameVariable)
        setGameVariable->setOperatorIndex(index);
}

void SetGameVariableEditorWidget::onValueEdited(const QString & text)
{
    SetGameVariable* setGameVariable = qobject_cast<SetGameVariable*>(mGameObject);
    if (setGameVariable)
        setGameVariable->setValue(text);
}

QStringList SetGameVariableEditorWidget::operatorsText()
{
    QStringList operators;
    for(int i=0; i < mOperatorChooser->count(); i++)
        operators << mOperatorChooser->itemText(i);

    return operators;
}
