/* Copyright (C) 2012-2014 Carlos Pais
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "wait_editor_widget.h"

#include <QDebug>

WaitEditorWidget::WaitEditorWidget(QWidget *parent) :
    ActionEditorWidget(parent)
{
    mWaitTypeWidget = new QComboBox(this);
    mWaitTypeWidget->addItem(tr("시간 지정"));
    mWaitTypeWidget->addItem(tr("마우스 버튼을 클릭할 때까지"));
    mWaitTypeWidget->addItem(tr("계속"));

    mSkipBox = new QCheckBox(this);
    mTimeSpin = new QDoubleSpinBox(this);
    mTimeSpin->setValue(1);
    mTimeSpin->setSingleStep(0.1);
    mTimeSpin->setMaximum(3600);

    beginGroup(tr("대기"));
    appendRow(tr("유형"), mWaitTypeWidget);
    appendRow(tr("시간(초)"), mTimeSpin);
    appendRow(tr("건너뛰기 허용"), mSkipBox);
    endGroup();

    resizeColumnToContents(0);

    connect(mWaitTypeWidget, SIGNAL(currentIndexChanged(int)), this, SLOT(onCurrentIndexChanged(int)));
    connect(mTimeSpin, SIGNAL(valueChanged(double)), this, SLOT(onTimeChanged(double)));
    connect(mSkipBox, SIGNAL(clicked(bool)), this, SLOT(onSkipBoxClicked(bool)));
}

void WaitEditorWidget::updateData(GameObject* action)
{
    ActionEditorWidget::updateData(action);
    Wait* wait = qobject_cast<Wait*>(action);
    if (! wait)
        return;

    mWaitTypeWidget->setCurrentIndex(wait->waitType());
    updateWidgets(mWaitTypeWidget->currentIndex());
    mTimeSpin->setValue(wait->time());
    mSkipBox->setChecked(wait->allowSkipping());
}

void WaitEditorWidget::onCurrentIndexChanged(int index)
{
    Wait* wait = qobject_cast<Wait*>(mGameObject);
    if (! wait)
        return;

    wait->setWaitTypeFromIndex(index);
    updateWidgets(index);
}

void WaitEditorWidget::onTimeChanged(double value)
{
    Wait* wait = qobject_cast<Wait*>(mGameObject);
    if (wait)
        wait->setTime(value);
}

void WaitEditorWidget::updateWidgets(int index)
{
    bool enabled = index >= 1 ? false : true;

    mSkipBox->setEnabled(enabled);
    mTimeSpin->setEnabled(enabled);
}

void WaitEditorWidget::onSkipBoxClicked(bool clicked)
{
    Wait* wait = qobject_cast<Wait*>(mGameObject);
    if (wait)
        wait->setAllowSkipping(clicked);
}
