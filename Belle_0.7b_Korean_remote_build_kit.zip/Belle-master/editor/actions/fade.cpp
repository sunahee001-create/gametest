/* Copyright (C) 2012-2014 Carlos Pais
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fade.h"

Fade::Fade(QObject *parent) :
    Action(parent)
{
    init();
}

Fade::Fade(const QVariantMap& data, QObject *parent) :
    Action(data, parent)
{
    init();
    loadInternal(data);
}

void Fade::init()
{
    setType(GameObjectMetaType::Fade);
    setSupportedEvents(Interaction::MousePress | Interaction::MouseRelease |
    Interaction::MouseMove);
    setFadeType(Fade::Out);
    mDuration = 1;
}

void Fade::loadData(const QVariantMap & data, bool internal)
{
    if (!internal)
        Action::loadData(data, internal);

    if (data.contains("fadeType") && data.value("fadeType").type() == QVariant::String)
        setFadeType(data.value("fadeType").toString());

    if (data.contains("duration") && data.value("duration").canConvert(QVariant::Double))
        setDuration(data.value("duration").toDouble());
}

Fade::Type Fade::fadeType()
{
    return mFadeType;
}

QString Fade::fadeTypeString() const
{
    return fadeTypeToString(mFadeType);
}

void Fade::setFadeType(Fade::Type type)
{
    mFadeType = type;
    QString namepart(tr("페이드 아웃"));

    if (type == Fade::In)
        namepart = tr("페이드 인");

    setTitle(QString("%1 %2").arg(tr("페이드")).arg(namepart));
    notify("fadeType", fadeTypeToString(type));
}

void Fade::setFadeType(const QString& type)
{
    if (type == "in")
        setFadeType(Fade::In);
    else
        setFadeType(Fade::Out);
}

QString Fade::fadeTypeToString(Fade::Type type) const
{
    if (type == 0)
        return "in";

    return "out";
}

double Fade::duration() const
{
    return mDuration;
}

void Fade::setDuration(double duration)
{
    if (duration != mDuration) {
        mDuration = duration;
        notify("duration", duration);
    }
}

QString Fade::displayText() const
{
    if (! this->sceneObject())
        return "";
    return QString("\"%1\" %2 %3s").arg(sceneObject()->objectName()).arg(tr("페이드 인")).arg(duration());
}

QVariantMap Fade::toJsonObject(bool internal) const
{
    QVariantMap data = Action::toJsonObject(internal);
    data.insert("fadeType", fadeTypeToString(mFadeType));
    data.insert("duration", QVariant(mDuration));

    return data;
}
