Belle 0.7b 한국어판 소스 코드 (작업본)

이 패키지는 사용자가 제공한 Belle-master 소스를 바탕으로 편집기 화면의
사용자 표시 문자열을 한국어로 옮긴 소스 코드입니다.

중요 사항
- Windows 실행 파일(EXE)은 포함되어 있지 않습니다.
- 이 환경에는 Qt 개발 도구(qmake)와 Qt WebKit 개발 모듈이 없어 실제 빌드 및 실행 테스트를 완료하지 못했습니다.
- 원본 프로젝트 파일(belle.pro)은 Qt의 core, network, webkitwidgets 모듈을 요구합니다.
- 원본 프로젝트의 README는 Qt 4를 언급하지만, 현재 belle.pro의 webkitwidgets 설정은 Qt 5 계열 구성을 가리킵니다. 따라서 개발 환경에 맞는 Qt 버전 및 Qt WebKit 호환성을 먼저 확인해야 합니다.
- 일부 전문 용어, CSS 글꼴 패밀리명, 내부 식별자 및 게임 엔진 문자열은 호환성을 위해 영어로 유지했습니다.
- 이 소스는 완전한 번역이나 검증된 바이너리가 아닌 번역 작업본입니다.

빌드 시도 방법
1. Qt 및 프로젝트에 필요한 Qt WebKit 개발 모듈을 설치합니다.
2. editor 폴더에서 qmake belle.pro 를 실행합니다.
3. 생성된 빌드 설정으로 컴파일합니다.
4. 원본 Belle 설치 폴더와 분리된 별도 폴더에서 실행 및 기능 테스트를 합니다.

라이선스
원본 프로젝트의 LICENSE 및 editor/COPYING.txt를 함께 보존했습니다.
