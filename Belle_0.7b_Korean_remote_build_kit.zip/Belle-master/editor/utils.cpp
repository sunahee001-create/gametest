#include "utils.h"
#include "imagefile.h"
#include "soundasset.h"
#include "fontasset.h"
#include <QFileDialog>

const QString FileDialogUtils::ImageFilter = FileDialogUtils::toFilter(QObject::tr("이미지"),
                                                                       ImageFile::supportedFormats());
const QString FileDialogUtils::SoundFilter = FileDialogUtils::toFilter(QObject::tr("사운드"),
                                                                       SoundAsset::supportedFormats());
const QString FileDialogUtils::FontFilter = FileDialogUtils::toFilter(QObject::tr("글꼴"),
                                                                       FontAsset::supportedFormats());
const QString FileDialogUtils::AllFilesFilter = "All Files (*)";

QString FileDialogUtils::getOpenImageFileName(QWidget* parent, const QString& dir, bool allFilesFilter)
{
   QString filters = FileDialogUtils::buildFilters(FileDialogUtils::ImageFilter, allFilesFilter);
   return QFileDialog::getOpenFileName(parent, QObject::tr("이미지 선택"), dir, filters);
}

QString FileDialogUtils::getOpenSoundFileName(QWidget* parent, const QString& dir, bool allFilesFilter)
{
   QString filters = FileDialogUtils::buildFilters(FileDialogUtils::SoundFilter, allFilesFilter);
   return QFileDialog::getOpenFileName(parent, QObject::tr("사운드 선택"), dir, filters);
}

QString FileDialogUtils::getOpenFontFileName(QWidget* parent, const QString& dir, bool allFilesFilter)
{
   QString filters = FileDialogUtils::buildFilters(FileDialogUtils::FontFilter, allFilesFilter);
   return QFileDialog::getOpenFileName(parent, QObject::tr("글꼴 선택"), dir, filters);
}

QString FileDialogUtils::toFilter(const QString &name, const QStringList &ext)
{
    QStringList formats;
    foreach(const QString& format, ext) {
        formats << "*." + format.toLower();
    }

    return QString("%1 (%2)").arg(name).arg(formats.join(" "));
}

QString FileDialogUtils::buildFilters(const QString& filter, bool allFilesFilter)
{
    QStringList filters;
    filters << filter;
    if (allFilesFilter)
        filters << FileDialogUtils::AllFilesFilter;
    return filters.join(";;");
}
