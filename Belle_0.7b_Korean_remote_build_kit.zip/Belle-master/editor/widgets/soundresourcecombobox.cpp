#include "soundresourcecombobox.h"

#include <QMessageBox>
#include <QMouseEvent>

SoundResourceComboBox::SoundResourceComboBox(QWidget *parent) :
    GameObjectComboBox(parent)
{
}

void SoundResourceComboBox::mouseReleaseEvent(QMouseEvent *event)
{
    if (!count()) {
        QMessageBox::information(this, tr("사용 가능한 사운드가 없습니다."), tr("Currently there are no sounds available in your project.\n"
                                                           "Please add them through the Resources section."));
    }

    GameObjectComboBox::mouseReleaseEvent(event);
}
