#include "gameobjectmetatype.h"

#include <QHash>

#include "actionmetatype.h"

static QHash<GameObjectMetaType::Type, GameObjectMetaType*> mGameObjectMetaTypes;

GameObjectMetaType::GameObjectMetaType(GameObjectMetaType::Type type, const QString& typeString,
                                       const QString& name, const QIcon& icon, QObject *parent) :
    QObject(parent)
{
    mType = type;
    mTypeString = typeString;
    mName = name;
    mIcon = icon;
}

const QIcon& GameObjectMetaType::icon() const
{
    return mIcon;
}

QString GameObjectMetaType::name() const
{
    return mName;
}

GameObjectMetaType::Type GameObjectMetaType::type() const
{
    return mType;
}

QString GameObjectMetaType::toString() const
{
    return mTypeString;
}

void GameObjectMetaType::init()
{
    if (! mGameObjectMetaTypes.isEmpty())
        return;

    mGameObjectMetaTypes.insert(GameObject, new GameObjectMetaType(GameObject, "GameObject", tr("게임 오브젝트")));

    //objects
    mGameObjectMetaTypes.insert(Object, new GameObjectMetaType(Object, "Object", tr("오브젝트")));
    mGameObjectMetaTypes.insert(TextBox, new GameObjectMetaType(TextBox, "TextBox", tr("텍스트 상자"), QIcon(":/media/text.png")));
    mGameObjectMetaTypes.insert(Button, new GameObjectMetaType(Button, "Button", tr("버튼"), QIcon(":/media/button.png")));
    mGameObjectMetaTypes.insert(Image, new GameObjectMetaType(Image, "Image", tr("이미지"), QIcon(":/media/image.png")));
    mGameObjectMetaTypes.insert(Character, new GameObjectMetaType(Character, "Character", tr("캐릭터"), QIcon(":/media/user.png")));
    mGameObjectMetaTypes.insert(ObjectGroup, new GameObjectMetaType(ObjectGroup, "ObjectGroup", tr("오브젝트 그룹")));
    mGameObjectMetaTypes.insert(DialogueBox, new GameObjectMetaType(DialogueBox, "DialogueBox", tr("대화 상자"), QIcon(":/media/talk-baloon.png")));
    mGameObjectMetaTypes.insert(Menu, new GameObjectMetaType(Menu, "Menu", tr("메뉴"), QIcon(":/media/menu.png")));
    mGameObjectMetaTypes.insert(MenuOption, new GameObjectMetaType(MenuOption, "MenuOption", tr("메뉴 선택지")));
    mGameObjectMetaTypes.insert(Sound, new GameObjectMetaType(Sound, "Sound", tr("사운드"), QIcon(":/media/sound.png")));
    mGameObjectMetaTypes.insert(SlotButton, new GameObjectMetaType(SlotButton, "SlotButton", tr("슬롯 버튼"), QIcon(":/media/button.png")));
    mGameObjectMetaTypes.insert(Font, new GameObjectMetaType(Font, "Font", tr("글꼴"), QIcon(":/media/font.png")));

    //scene
    mGameObjectMetaTypes.insert(Scene, new GameObjectMetaType(Scene, "Scene", tr("장면")));

    //actions
    mGameObjectMetaTypes.insert(Action, new GameObjectMetaType(Action, "Action", tr("액션")));
    mGameObjectMetaTypes.insert(Show, new GameObjectMetaType(Show, "Show", tr("표시"), QIcon(":/media/show.png")));
    mGameObjectMetaTypes.insert(Hide, new GameObjectMetaType(Hide, "Hide", tr("숨기기"), QIcon(":/media/hide.png")));
    mGameObjectMetaTypes.insert(Wait, new GameObjectMetaType(Wait, "Wait", tr("대기"), QIcon(":/media/timer.png")));
    mGameObjectMetaTypes.insert(Dialogue, new GameObjectMetaType(Dialogue, "Dialogue", tr("대화"), QIcon(":/media/talk-baloon.png")));
    mGameObjectMetaTypes.insert(Slide, new GameObjectMetaType(Slide, "Slide", tr("슬라이드"), QIcon(":/media/slide.png")));
    mGameObjectMetaTypes.insert(Fade, new GameObjectMetaType(Fade, "Fade", tr("페이드"), QIcon(":/media/fade.png")));
    mGameObjectMetaTypes.insert(Label, new GameObjectMetaType(Label, "Label", tr("레이블"), QIcon(":/media/label.png")));
    mGameObjectMetaTypes.insert(GoToLabel, new GameObjectMetaType(GoToLabel, "GoToLabel", tr("레이블로 이동"), QIcon(":/media/go-to-label.png")));
    mGameObjectMetaTypes.insert(GoToScene, new GameObjectMetaType(GoToScene, "GoToScene", tr("장면으로 이동"), QIcon(":/media/go-to-scene.png")));
    mGameObjectMetaTypes.insert(Branch, new GameObjectMetaType(Branch, "Branch", tr("분기"), QIcon(":/media/branch.png")));
    mGameObjectMetaTypes.insert(GetUserInput, new GameObjectMetaType(GetUserInput, "GetUserInput", tr("사용자 입력 받기"), QIcon(":/media/edit-clear.png")));
    mGameObjectMetaTypes.insert(ShowMenu, new GameObjectMetaType(ShowMenu, "ShowMenu", tr("메뉴 표시"), QIcon(":/media/menu.png")));
    mGameObjectMetaTypes.insert(ChangeObjectBackground, new GameObjectMetaType(ChangeObjectBackground, "ChangeObjectBackground", tr("오브젝트 배경 변경"), QIcon(":/media/color.png")));
    mGameObjectMetaTypes.insert(PlaySound, new GameObjectMetaType(PlaySound, "PlaySound", tr("사운드 재생"), QIcon(":/media/sound.png")));
    mGameObjectMetaTypes.insert(StopSound, new GameObjectMetaType(StopSound, "StopSound", tr("사운드 정지"), QIcon(":/media/no-sound.png")));
    mGameObjectMetaTypes.insert(SetGameVariable, new GameObjectMetaType(SetGameVariable, "SetGameVariable",
                                                                           tr("게임 변수 설정"), QIcon(":/media/script.png")));
    mGameObjectMetaTypes.insert(ChangeBackground, new GameObjectMetaType(ChangeBackground, "ChangeBackground", tr("배경 변경"), QIcon(":/media/image.png")));
    mGameObjectMetaTypes.insert(RunScript, new GameObjectMetaType(RunScript, "RunScript", tr("스크립트 실행"), QIcon(":/media/script.png")));
    mGameObjectMetaTypes.insert(ChangeState, new GameObjectMetaType(ChangeState, "ChangeState", tr("상태 변경"), QIcon(":/media/user-group.png")));
    mGameObjectMetaTypes.insert(End, new GameObjectMetaType(End, "End", tr("끝내기"), QIcon(":/media/end-novel.png")));

    ActionMetaType::init();
}

void GameObjectMetaType::destroy()
{
    QHashIterator<GameObjectMetaType::Type, GameObjectMetaType*> it(mGameObjectMetaTypes);

    while(it.hasNext()) {
        it.next();
        GameObjectMetaType* metaType = it.value();
        if (metaType)
            metaType->deleteLater();
    }

    mGameObjectMetaTypes.clear();
}

const GameObjectMetaType* GameObjectMetaType::metaType(Type type)
{
    return mGameObjectMetaTypes.value(type, 0);
}

const QIcon& GameObjectMetaType::icon(Type type)
{
    const GameObjectMetaType* metaType = GameObjectMetaType::metaType(type);
    if (metaType)
        return metaType->icon();
    return QIcon();
}

GameObjectMetaType::Type GameObjectMetaType::typeFromString(const QString& typeString)
{
    QHashIterator<GameObjectMetaType::Type, GameObjectMetaType*> it(mGameObjectMetaTypes);
    QString typeStringLower = typeString.toLower();

    //For backwards compatibility. Remove at some point.
    if(typeStringLower == "changegamevariable")
        typeStringLower = "setgamevariable";
    if (typeStringLower == "changecolor")
        typeStringLower = "changeobjectbackground";

    while(it.hasNext()) {
        it.next();
        GameObjectMetaType* metaType = it.value();
        if (metaType && metaType->toString().toLower() == typeStringLower) {
            return metaType->type();
        }
    }

    return GameObjectMetaType::UnknownType;
}
